main() {
  Map<String, int> villes = {
    'Kinshasa': 22,
    'Brazzaville': 20,
    'Kigali': 15,
    'Alger': 11,
  };
  villes.forEach((villes, temperature) {
    print('il fait $temperature degres a $villes');
  });
}
